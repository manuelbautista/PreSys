$(document).ready(function () {
    $('#textarea').wysihtml5();
});