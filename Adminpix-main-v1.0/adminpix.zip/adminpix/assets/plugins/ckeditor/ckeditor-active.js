$(document).ready(function () {
    "use strict"; // Start of use strict
    CKEDITOR.replace('editor1');
});